/** SPI_Init.c
 *
 *  Created on: Jan. 17, 2025
 *      Author: Canobby.ca
***/

#include "Periphs.h"
#include "FreeRTOS.h"
#include "task.h"

void Init_SPIs( uint8_t msk ) {

    GPIO_InitTypeDef GPIO_InitStructure = {0};
    SPI_InitTypeDef  SPI_InitStructure = {0};

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );
//    printf("ISPI: SPI %X\n", msk);
    if( msk & SPI2_msk ) RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );
    if( msk & SPI1_msk ) { RCC_APB2PeriphClockCmd( RCC_APB2Periph_SPI1,  ENABLE );
//    	printf("InitSPI: Clk SPI1 for 0x%X\n", msk);
    }
    if( msk & SPI2_msk ) RCC_APB1PeriphClockCmd( RCC_APB1Periph_SPI2,  ENABLE );
    if( msk & SPI3_msk ) RCC_APB1PeriphClockCmd( RCC_APB1Periph_SPI3,  ENABLE );

    if( msk & SPI1_msk ) { GPIO_InitStructure.GPIO_Pin =  SPI1_MOSI;

//    if( msk & SPI3_msk ) GPIO_InitStructure.GPIO_Pin |= SPI3_MOSI;
//    if( msk & ( SPI1_msk | SPI3_msk )) {
    GPIO_InitStructure.GPIO_Mode  = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
// printf("InitSPI: GPIO pin for 0x%X = %d\n", msk, GPIO_InitStructure.GPIO_Pin );
    }
    GPIO_Init(GPIOA, &GPIO_InitStructure);
//    									}

/**   GPIO B SPI2 ???  */

    SPI_SSOutputCmd(SPI1, ENABLE);
    SPI_InitStructure.SPI_Direction = SPI_Direction_1Line_Tx;

    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;

    SPI_InitStructure.SPI_DataSize = SPI_DataSize_16b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;
//    SPI_InitStructure.SPI_NSS = SPI_NSS_Hard;
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_64;
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_LSB;
    SPI_InitStructure.SPI_CRCPolynomial = 7;  //  7 = no poly
    SPI_Init(SPI1, &SPI_InitStructure);

SPI_I2S_DMACmd(SPI1, SPI_I2S_DMAReq_Tx, ENABLE);

//    SPI1->DATAR = 0;

    SPI_Cmd(SPI1, ENABLE);
}

// void DMA_Tx_Init( DMA_Channel_TypeDef *DMA_Ch, uint32_t *SPI_DATAR, uint32_t TxData, uint16_t Size );

void DMA_Tx_Init( DMA_Channel_TypeDef *DMA_CHx, uint32_t ppadr, uint32_t memadr, uint16_t bufsize )
{
    DMA_InitTypeDef DMA_InitStructure = {0};

    RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

    DMA_DeInit(DMA_CHx);

    DMA_InitStructure.DMA_PeripheralBaseAddr = ppadr;
    DMA_InitStructure.DMA_MemoryBaseAddr = memadr;
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralDST;
    DMA_InitStructure.DMA_BufferSize = bufsize;
//    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Enable;
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;
//    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Disable;
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord;
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;
    DMA_InitStructure.DMA_Mode = DMA_Mode_Normal;

    DMA_InitStructure.DMA_Priority = DMA_Priority_VeryHigh;
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;
    DMA_Init(DMA_CHx, &DMA_InitStructure);

}

void SPI_Send( uint16_t dta ) {

	SPI_I2S_SendData( SPI1, dta );
//	printf("SS=%0X\n", dta );

}

