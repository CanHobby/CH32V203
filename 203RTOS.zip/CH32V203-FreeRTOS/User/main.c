/********************************** (C) COPYRIGHT *******************************
 * File Name          : main.c
 * Author             : WCH
 * Version            : V1.0.0
 * Date               : 2023/12/29
 * Description        : Main program body.
 *********************************************************************************
 * Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
 * Attention: This software (modified or not) and binary are used for 
 * microcontroller manufactured by Nanjing Qinheng Microelectronics.
 *******************************************************************************/

/*
 *@Note
 *task1 and task2 alternate printing
 */

#include "Periphs.h"
#include "debug.h"
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "NEO.h"

/* Global define */
#define TASK1_TASK_PRIO     5
#define TASK1_STK_SIZE      256
#define TASK2_TASK_PRIO     5
#define TASK2_STK_SIZE      256

/* Global Variable */
TaskHandle_t      Strip1Task_Handler;
SemaphoreHandle_t Strip1Semph;
TaskHandle_t 	  Task2Task_Handler;
TaskHandle_t 	  AnimTask_Handler;

// extern uint32_t Blank[ ];
extern uint32_t Strip[ ];

strip Neo1;

/*********************************************************************
 * @fn      GPIO_Toggle_INIT
 * @brief   Initializes GPIOA.0/1
 * @return  none
 */
void GPIO_Toggle_INIT(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure={0};

  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_3;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void CH_Delay_Us( uint32_t d ) {

    for( uint64_t cd=0; cd<5*d;cd++) {
    	asm("nop"); asm("nop"); asm("nop"); asm("nop");
    	asm("nop"); asm("nop"); asm("nop"); asm("nop");
    }

}

/*********************************************************************
 * @fn      Anim task
 * @brief   Animation task program.
 * @param  *pvParameters - Parameters point of task1
 * @return  none
 */

void anim_task(void *pvParameters)
{
	vTaskSuspend( NULL );  //  Suspend ourself until the Strips are up and running.
	printf("Anim Task Setup\n");
    vTaskDelay( 140 );
    Neo1.segs[0][START] = 3;
    Neo1.segs[0][END]   = 9;
    Neo1.segs[0][SIZE]  = 4;
    Neo1.segs[0][BRT]   = MAG;

    while(1)
    {
        if( xSemaphoreTake( Strip1Semph, ( TickType_t ) 2000 ) == pdTRUE )
        	 { /* printf("Anim: 81 Take OK\n"); */ }
        else { printf("Anim: 82 Take FAILED!!!\n"); }

        moveSeg_R( &Neo1, 0, false, 8 ); //  vTaskDelay( 200 );

        if( xSemaphoreGive( Strip1Semph ) == pdTRUE )
        	 { /* printf("Anim: 87 Give OK\n"); */ }
        else { printf("Anim: 88 Give FAILED\n"); }
        vTaskDelay( 30 );
    }
}

void Blink_task(void *pvParameters)
{

	printf("Blnk Task Setup\n");
	GPIO_Toggle_INIT();
//    GPIO_SetBits(GPIOA, GPIO_Pin_1);

    while(1)
    {
        GPIO_SetBits(GPIOA, GPIO_Pin_0);
        vTaskDelay(150);
        GPIO_SetBits(GPIOA, GPIO_Pin_1);
        vTaskDelay(130);
        GPIO_ResetBits(GPIOA, GPIO_Pin_0);
        vTaskDelay(50);
        GPIO_ResetBits(GPIOA, GPIO_Pin_1);
        vTaskDelay(60);
    }
}

/*********************************************************************
 * @fn      NEO display task
 * @brief   task2 program.
 * @param  *pvParameters - Parameters point of task2
 * @return  none
 */
void Strip1_task(void *pvParameters)
{
#define STRIP1_LEN 15

	printf("NEO1 Task Setup (%d Leds)\n", STRIP1_LEN );
    Create_pStrip( &Neo1, 15, BLK, NULL );
    Init_SPIs( SPI1_msk );
    Clear( STRIP1_LEN );
    vTaskDelay( 800 );
#ifdef USEDMA
    DMA_Tx_Init(DMA1_Channel3, (uint32_t)&SPI1->DATAR, (uint32_t)Neo1.oStg, Neo1.len*5 );
#endif
    Strip1Semph = xSemaphoreCreateBinary();

    if( Strip1Semph == NULL )
    	{ printf("Semaphore creation failed - Memory?\n"); }

    if( xSemaphoreGive( Strip1Semph ) == pdTRUE )
    	 { /* printf("Strip1: 124 Give OK\n"); */ }
    else { printf("Strip1: 125 Give FAIL!!\n"); }

    vTaskResume( AnimTask_Handler );  //  AnimTask has been waiting on us

    while(1)
    {
        if( xSemaphoreTake( Strip1Semph, ( TickType_t ) 4000 ) == pdFALSE )
        	{ printf("Strip1: 132 Take FAIL!!\n"); }

        Compress5( &Neo1 );

        if( xSemaphoreGive( Strip1Semph ) == pdFALSE )
        	 { printf("Strip1: 145 GIVE FAIL!!\n"); }

        vTaskDelay( 1 );
    }
}

/*************************************
 * DMAspi
 * SPI_FullDuplex_Init();
    Delay_Ms(2000);
    DMA_Tx_Init(DMA1_Channel3, (u32)&SPI1->DATAR, (u32)TxData, Size);
    DMA_Cmd(DMA1_Channel3, ENABLE);
 *     while(1) {
        while((!DMA_GetFlagStatus(DMA1_FLAG_TC2)) && (!DMA_GetFlagStatus(DMA1_FLAG_TC3)));
        printf("\nCnt = %d\n", cnt++ );
        Delay_Ms( 2000 );
   }
 * *********************************/

int main(void)
{
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);
    SystemCoreClockUpdate();
    Delay_Init();
    USART_Printf_Init(115200);
    printf("\nCanHobby Clk=%d MHz\n",SystemCoreClock / 1000000 );
    ChipID();
    printf("FreeRTOS Kernel Version:%s\n",tskKERNEL_VERSION_NUMBER);

//    Clear( 15 );


/* create task */
//    Strip1Semph = xSemaphoreCreateBinary();
//    printf("FreeRTOS: %s\r\n", "tskKERNEL_VERSION_NUMBER" );
    Delay_Ms( 1500 );
    printf("\n");
/****/
    xTaskCreate((TaskFunction_t )Blink_task,
                    (const char*    )"Blink",
                    (uint16_t       )TASK1_STK_SIZE,
                    (void*          )NULL,
                    (UBaseType_t    )TASK1_TASK_PRIO,
                    (TaskHandle_t*  )&Strip1Task_Handler);
/****/
/***/
    xTaskCreate((TaskFunction_t )anim_task,
                    (const char*    )"Anim",
                    (uint16_t       )TASK1_STK_SIZE,
                    (void*          )NULL,
                    (UBaseType_t    )TASK2_TASK_PRIO,
                    (TaskHandle_t*  )&AnimTask_Handler );
/*****/
    xTaskCreate((TaskFunction_t )Strip1_task,
                        (const char*    )"NEO display",
                        (uint16_t       )TASK2_STK_SIZE,
                        (void*          )NULL,
                        (UBaseType_t    )TASK2_TASK_PRIO,
                        (TaskHandle_t*  )&Task2Task_Handler);

/***/
//    Delay_Ms(1500);
//    vTaskDelay(1500);
    vTaskStartScheduler();
//
 /* ***/
    while(1); // Delay_Ms( 1000 );
    {
//    	SPI_Send( 0x4664 );
        printf("shouldn't get at here!!\n");
    }
}

