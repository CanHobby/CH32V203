/** NEO.h
 *  Created on: Oct. 17, 2024
 *  Updated on: Dec. 19, 2024
 *  Author: CanHobby.ca
 */

#ifndef USER_NEO_H_
#define USER_NEO_H_

#define XMAS_ANIM
// #define BRTST_ANIM

#include "stdbool.h"
#include "stdlib.h"
#include "stdint.h"

#define START 0
#define END   1
#define SIZE  2
#define YY	  3
#define BRT	  4
#define FWD   1

#define FALSE 0
#define TRUE  1
#define DMA	  FALSE // TRUE  //  FALSE

#define NUM_STRIPS 3   //  Min 1  --  Max 3
#define MAX_LEN    144 // Length of longest strip

//  We aren't using C++ but we will use this object for each strip
typedef struct {
	uint32_t *pixels;
	uint16_t *bkg;		// Backup copy of pixels
	uint16_t  len;
	uint32_t  segs[5][5];   // up to 5 segments with 5 static parameters
	uint32_t *seg_d[5];		// segment data
} strip;

void SPIsetup( );
void Show( ); // , uint8_t num, bool dma );
// void Bop( uint8_t idx, uint16_t tick, uint32_t col, bool bi );
void Create_pStrip( strip *strp, uint16_t cnt, int32_t col, uint32_t* cols );
void fillSeg( uint8_t idx, uint8_t seg, uint32_t col, uint32_t *seq );
void moveSeg( uint8_t idx, uint8_t seg, bool dir, uint16_t tick );
void moveSeg_R( strip *strp, uint8_t seg, bool dir, uint16_t tick );
void rndSeg( uint8_t idx, uint8_t seg, uint16_t tick );
void brtSeg( uint8_t idx, uint8_t seg, uint16_t tick, uint32_t bmax );
void testBRT( uint32_t *buf );
// void fillStrip( uint8_t idx, uint32_t col, uint32_t *seq );
void Compress2( strip *strp );
void Compress3( strip *strp );
void Compress4( strip *strp );
void Compress5( strip *strp );
void Clear( uint8_t s );

#define RED 0x000400	// GRB  format
#define RDD 0x00FF00
#define grn 0x800000
#define grN 0x000001
#define GRN 0x030000
#define BLU 0x000005
#define MAG 0x000403
#define YEL 0x030300
#define CYN 0x030005
#define BLK 0x000000
#define WHT 0x040201

// #define MAX 15



#endif /* USER_NEO_H_ */
