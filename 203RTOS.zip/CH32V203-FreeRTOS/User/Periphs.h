/*
 * Periphs1.h
 *
 *  Created on: Jan. 17, 2025
 *      Author: ch32v
 */

#ifndef USER_PERIPHS1_H_
#define USER_PERIPHS1_H_

#include "debug.h"
#include "ch32v20x_gpio.h"
// #include "NEO.h"


#define SPI1_msk  1
#define SPI1_MOSI GPIO_Pin_7
#define SPI2_msk  2
#define SPI2_MOSI GPIO_Pin_15
#define SPI3_msk  3
#define SPI3_MOSI GPIO_Pin_9

#define LED1_pin     GPIO_Pin_0
#define LED1_Port GPIOA
#define LED1_ClkPort RCC_APB2Periph_GPIOA   //  LED1 (203) is on GPIO A0
#define LED2_pin GPIO_Pin_1
#define LED2_Port GPIOA
#define LED2_ClkPort  RCC_APB2Periph_GPIOA  //  LED2 (203) is on GPIO A1

void Init_SPIs( uint8_t msk );
void DMA_Tx_Init( DMA_Channel_TypeDef *DMA_Ch, uint32_t SPI_DATAR, uint32_t TxData, uint16_t Size );
void SPI_Send( uint16_t dta );
void CH_Delay_Us( uint32_t d );
uint32_t ChipID();

#endif /* USER_PERIPHS1_H_ */
