/*
 * Neo.c
 *  Updated on: Dec. 19, 2024
 *  Created on: Oct. 15, 2024
 *      Author: CanHobby.ca
 */

// #include "CH58x_common.h"
#include "NEO.h"
#include "Periphs.h"
#include <string.h>
#include "FreeRTOS.h"
#include "task.h"

uint32_t Short[ ] =  { RED, MAG };
uint32_t Strip[ ] =  { RED, GRN, BLU, YEL, MAG, CYN, YEL, BLK, WHT, BLU, MAG, RED, BLU, MAG, MAG, \
		               RED, grN, RED, MAG, RED, YEL, CYN, RED, GRN, BLU, MAG, RED, BLU, MAG, MAG,  };
uint32_t Strip2[ ] = { GRN, GRN, GRN, BLU, GRN, MAG, BLK, MAG, BLU, YEL, CYN, RED, GRN, BLU, MAG, \
					   RED, GRN, RED, MAG, RED, YEL, CYN, RED, GRN, BLU, MAG, RED, BLU, MAG, MAG, };
uint32_t Blank[] =   { MAG, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK, BLK };
uint32_t Xmas[32] =  { BLK, RED, BLK, BLK, YEL, BLK, BLK, BLK, BLK, RED, BLK, BLK, BLK, MAG, BLK, BLU, \
					   GRN, BLK, BLK, BLK, BLK, GRN, BLK, BLK, BLK, BLK, BLK, BLK, MAG, BLK, BLK, BLK	};

uint32_t Test1[ ] =  { 0x6, 0x304, 0x6, 0x7, 0x8, 0x9 };  // GRB
uint32_t *Test2, *Test3;

extern strip Strips[];
extern uint16_t mstTick;

uint8_t  pbuf[128];
uint8_t curStrip = 0;

void Create_pStrip( strip *strp, uint16_t cnt, int32_t col, uint32_t* bkg ) {

	uint16_t x;

	strp->pixels = (uint32_t*)calloc( cnt, sizeof(uint32_t) );

	strp->bkg    = (uint32_t*)calloc( cnt, sizeof(uint32_t) );

	strp->len    = cnt;

	if( col > -1) {
		for( x=0; x<cnt; x++ ) strp->pixels[x] = col;
	} else if( bkg ) {
		memcpy( strp->pixels, bkg, cnt * sizeof(uint32_t) );
	}
//	printf("\npx = %08X: %06X\n", strp->pixels, strp->pixels[1] );
//	printf("oS = %04X: %04X\n", strp->oStg, strp->oStg[1] );
}

/******  Brightness control and normalization    *******************************************/

uint32_t setBRT( uint32_t in, uint8_t brt ) {

	uint32_t ret = 0;

	if( in & 0x0000FF ) ret =  brt;
	if( in & 0x00FF00 ) ret |= brt << 8;
	if( in & 0xFF0000 ) ret |= brt << 16;

	return ret;

}
/**
void testBRT( uint32_t *buf ) {

	for( int x=0; x<3; x++ ) {
		printf( "0x%06X:0x%06X  ", buf[x], setBRT( buf[x], 8) );
	}
	printf( "\n\n" );
}
****/
/******  ANIMATIONs *******************************************************
 * Animations affect segments
 * They typically modify a singles pixel in a segment on each pass through the Endless loop
 * which ends in the Show() function displaying all of the updated strips which are
 * made up of segments.
 * The 'YY' field in the structure keeps track of which pixel is currently being modified
 * they would normally be sequenced from 'START'  to 'END'
 *
 * *********************  fillSeg  ******************************************

 * @param idx  -- strip to be animated.
 * @param seg  -- segment to be modified.
 * @param col  -- solid colour to fill with - ignored if seq is not NULL.
 * @param seq  -- array of colours to be used.
 */

void fillSeg( uint8_t idx, uint8_t seg, uint32_t col, uint32_t *seq ) {
	uint16_t x, isz;

	isz = Strips[idx].segs[seg][ SIZE ];
	Strips[ idx ].seg_d[seg] = (uint32_t*)calloc( isz, sizeof(uint32_t) );

		for( x=0; x<=isz; x++ ) {
			if(!seq) { Strips[ idx ].seg_d[seg][x] = col; }
	    else         { Strips[ idx ].seg_d[seg][x] = seq[x]; }
		}
  }


void moveSeg_R( strip *strp, uint8_t seg, bool dir, uint16_t tick ) {

uint16_t  cnt, x, z, isz, strt, end; // ox, , osz_ isz_, osz, ;
uint32_t *bkg;
// uint32_t *ip, *op, *bkg;
uint16_t  y;

strt = strp->segs[seg][START] - 1;
end  = strp->segs[seg][ END ];

// printf("moveSeg_R: 8 = %X\n", strp->pixels[ 8 ] ); // strt = %d, seg = %d, YY = %d\n", strt, seg, strp->segs[0][YY] );

//	ip  = strp->seg_d[seg];  //  InPut Pointer
	isz = strp->segs[seg][ SIZE ];

//	 memcpy( bkg, &strp->pixels[0], strp->len * sizeof(uint32_t) );  //  Save a copy of the existing background

	//	strp->pixels[ end ] = RED; //  STOP SIGN for debugging

	if( !strp->segs[seg][YY] ) { strp->segs[seg][YY] = strt; }
	y = strp->segs[seg][YY];

	if( ( y >= strt) && ( y < end ) ) strp->pixels[ y ] = strp->segs[seg][BRT];  // Move Seg on down the line
	if( ( y > (strt + isz - 1)) && ( y < (end + isz) ) ) strp->pixels[ y - isz + 0 ] = strp->bkg[y]; // BackFill with Background

// printf("BKG = %X, %X, %X -- %d\n", bkg[y-1], bkg[y], bkg[y+1], y );

	strp->segs[0][YY]++;
//	strp->segs[seg][START] = 72;

 if( strp->segs[seg][YY] > end + isz ) {
	 strp->segs[seg][YY] = strt;
 	 	 	 	 }

// CH_Delay_Us( tick * 1000 );
// vTaskDelay( tick * 4 );
   }  // End moveSegR

void moveSeg( uint8_t idx, uint8_t seg, bool dir, uint16_t tick ) {

if( !(mstTick % tick) ) {

uint16_t  cnt, x, z, isz, strt, end; // ox, , osz_ isz_, osz, ;
uint32_t *ip, *op;
uint16_t  y; // = Strips[idx].segs[seg][YY];
// uint32_t *bkg;

// ox = Strips[idx].segs[seg][ START ] - 1; // OutPut index - We start at 1 NOT 0
strt = Strips[idx].segs[seg][START] - 1;
end  = Strips[idx].segs[seg][ END ];

// printf("moveSeg: strt = %d, end = %d\n", strt, end );

//	if( !cnt ) { cnt = end - strt +1; }
/***
	if( !bkg ) { bkg = (uint32_t*)calloc( cnt, sizeof(uint32_t) );
		memcpy( bkg, op, cnt * sizeof(uint32_t) );  //  Save a copy of the existing background
				}

if( idx == 69 ) {
	printf("end = %d, y = %d\n", end, y );
//		printf("end = %d, op = %X\n", end, op );
//		printf("BKG = %X :: %X -- %d\n", bkg, *bkg, cnt );
//		printf("Bkg = %X, %X, %X\n", bkg[0], bkg[1], bkg[2] );
//	}
		}
***/
	ip  = Strips[idx].seg_d[seg];  //  InPut Pointer
	isz = Strips[idx].segs[seg][ SIZE ];

//   4. 16, 3

	Strips[ idx ].pixels[ end + 0 ] = RED; //  STOP SIGN


//	 memcpy( bkg, &op, cnt * sizeof(uint32_t) );  //  Save a copy of the existing background
//	 memcpy( bkg, &Strips[idx].[ Strips[idx].segs[seg][BEGIN]], cnt * sizeof(uint32_t) );
// printf("BKG = %X, %X, %X\n", *bkg, *bkg+1, bkg+2 );

	y = Strips[idx].segs[seg][YY];
// if( idx == 2 ) { printf("End = %d, Y = %d\n", end, y ); }
// printf("y=%d : %%=%d isz %d\n", y, y%isz, isz );
	if( (y < end) && (y >= strt)  ) Strips[idx].pixels[ y ] = ip[y%isz]; // Strip[ y % isz ];  // grn;  //  Move Seg on down the line
	if( (y < end+isz) && (y>strt + isz - 1) ) Strips[idx].pixels[ y - isz + 0 ] = BLK; // bkg[y]; // BackFill with Background

// printf("BKG = %X, %X, %X -- %d\n", bkg[y-1], bkg[y], bkg[y+1], y );

	Strips[idx].segs[seg][YY]++;

 if( Strips[idx].segs[seg][YY] > end + isz ) {
	 Strips[idx].segs[seg][YY] = 0;
 	 	 	 	 }

	  }  //  End tick

   }  // End moveSeg

/**** brtSeg is a type of "Fader" used to control the brightness of individual segments
 *
 * @param idx
 * @param seg
 * @param tick
 * @param bmax  --  max brightness limit
 ******************/

void brtSeg( uint8_t idx, uint8_t seg, uint16_t tick, uint32_t bmax ) {

if( !(mstTick % tick) ) {

//	printf("brtSeg: 0x%X _d = 0X%X\n", Strips[idx].pixels[28], Strips[idx].seg_d[seg] );

	uint16_t strt, end, isz, y;
	uint32_t max;

strt = Strips[idx].segs[seg][START];
end  = Strips[idx].segs[seg][ END ];
isz =  Strips[idx].segs[seg][ SIZE ];
// ip  = Strips[idx].seg_d[seg];  //  InPut Pointer

	Strips [ idx ].pixels[ end ] = RED; //  STOP SIGN

	if( Strips[idx].seg_d[seg] ) {  //  Operate on the prefilled segment
//		printf("brtSeg do d_seg: 0x%08X _d = 0X%08X\n", Strips[idx].seg_d[seg][0], Strips[idx].seg_d[seg] );
		for( y=0; y<isz; y++ ) {
			Strips[idx].seg_d[seg][y] += Strips[idx].segs[seg][ BRT ];
//			Strips[idx].pixels[y] = YEL; // += Strips[idx].segs[seg][ BRT ];
			if( Strips[idx].seg_d[seg][y] > bmax ) Strips[idx].seg_d[seg][y] = Strips[idx].segs[seg][ BRT ];
			}
	} else { // Operate on a raw segment
	for( y=strt; y<end; y++ ) {
		Strips[idx].pixels[y] += Strips[idx].segs[seg][ BRT ];
		if( Strips[idx].pixels[y] > bmax ) Strips[idx].pixels[y] = Strips[idx].segs[seg][ BRT ];
		}
	}

	  }  //  End tick

   }  // End brtSeg


void rndSeg( uint8_t idx, uint8_t seg, uint16_t tick ) {

if( !(mstTick % tick) ) {

// uint16_t  cnt, x, z, isz, strt, end, y; // ox, , osz_ isz_, osz, ;
uint16_t  strt, end, isz, y;
uint32_t *ip, *op;
uint8_t  p, c, brt;

strt = Strips[idx].segs[seg][START] - 1;
end  = Strips[idx].segs[seg][ END ];
brt  = (uint8_t)Strips[idx].segs[seg][ BRT ];

isz = Strips[idx].segs[seg][ SIZE ];

///	Strips[ idx ].pixels[ end ] = RED; //  STOP SIGN for debugging

	p = rand() % end;
	c = rand() % sizeof(Xmas) / sizeof(uint32_t);

	y = Strips[idx].segs[seg][YY];

//	if( (y < end) && (y >= strt)  )
	Strips[idx].pixels[ p ] = setBRT( Xmas[ c ], brt ); // WHT;

//	Strips[idx].segs[seg][YY]++;

 if( Strips[idx].segs[seg][YY] > end + isz ) {
//	 Strips[idx].segs[seg][YY] = 0;
 	 	 	 	 }

	  }  //  End tick

   }  // End rndSeg

/****/
void Compress5( strip *strp ) {

// printf("C");

uint8_t  x, y, z;
uint16_t t;
//	GPIOA_SetBits( bSCS );  //  for the benefit of the Logic Analyzer
	for( x = 0; x<strp->len; x++ ) { // pixels in Strip
//		printf("%08X: ", strp->pixels[x] );
		y = 25; t = 0;// bits in pixel
		   do {
			y--;
			if( y!=24) {
			if( strp->pixels[x] & (1<<y) ) { t  = 0x6000; }
				                  	  else { t  = 0x4000; }
			}
			y--;
			if( strp->pixels[x] & (1<<y) ) { t |= 0x0C00; }
				                  	  else { t |= 0x0800; }
			y--;
			if( strp->pixels[x] & (1<<y) ) { t |= 0x0180; }
			                   	   	  else { t |= 0x0100; }
			y--;
			if( strp->pixels[x] & (1<<y) ) { t |= 0x0030; }
							   	   	  else { t |= 0x0020; }
			y--;
			if( strp->pixels[x] & (1<<y) ) { t |= 0x0006; }
							   	   	  else { t |= 0x0004; }

//			printf("%04X ", t );
#ifdef USEDMA
			strp->oStg[ z ] = t; z++;
#endif
			while( SPI_I2S_GetFlagStatus( SPI1, SPI_I2S_FLAG_TXE ) == RESET );
			SPI_Send( t ); // strp->oStg[ z ] ); // z++;

	  } while( y > 0 );


//		   for( x=0; x<12; x++ ) {
//				while( SPI_I2S_GetFlagStatus( SPI1, SPI_I2S_FLAG_TXE ) == RESET );
//				SPI_Send( 0x4446 ); // strp->oStg[ x ] );
//			   printf("%04X ", strp->oStg[ x ] );
//		   }

//		   printf("\n"); Delay_Ms( 6000 );

	}

//	GPIO_ResetBits(GPIOA, GPIO_Pin_3);
#ifdef USEDMA
	   DMA_Cmd( DMA1_Channel3, ENABLE );
	   while( (!DMA_GetFlagStatus(DMA1_FLAG_TC3)) );
	   DMA_Cmd( DMA1_Channel3, DISABLE );
//  DMA_ClearFlag( DMA1_FLAG_TC3 );
	   GPIO_SetBits(GPIOA, GPIO_Pin_3);
//	   printf("DMA Flag = %X\n", DMA1->INTFR );
#endif
}  //  End compress5()
/****/



void Clear( uint8_t s ) {

	int x;

	for(x=0; x<s*5; x++ ) {
		SPI_Send( 0x924 );

		while( SPI_I2S_GetFlagStatus( SPI1, SPI_I2S_FLAG_TXE ) == RESET );

//		Delay_Us( 2 );
//		Delay_Us( 20 );
	}

}

