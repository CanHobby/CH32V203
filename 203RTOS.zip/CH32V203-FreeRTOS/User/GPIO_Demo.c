/** Gpio_Demo.c
 *  Created on: Jan. 8, 2025
 *      Author: CanHobby.ca
**/

// #include "ch32v00x_gpio.h"
#include "Periphs.h"

#define BlueLED_ClkPort RCC_APB2Periph_GPIOC  //  Blue LED is on   GPIO D0
#define YelLED_ClkPort  RCC_APB2Periph_GPIOD  //  Yellow LED is on GPIO C0


void  GPIO_Setup() { // Init the LED GPIOs

    GPIO_InitTypeDef GPIO_InitStructure = {0}; //  Init the GPIO structure

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    if( ( DBGMCU_GetCHIPID() >> 20 )  == 203 ) printf("203\r\n");
//    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_30MHz;

#ifdef TIMER_DEMO
    RCC_APB2PeriphClockCmd( YelLED_ClkPort, ENABLE );
    GPIO_InitStructure.GPIO_Pin = YelLED;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_30MHz;
    GPIO_Init( YelLED_Port, &GPIO_InitStructure);
#endif

#ifdef SISTICK_DEMO
    RCC_APB2PeriphClockCmd( BlueLED_ClkPort, ENABLE);
    GPIO_InitStructure.GPIO_Pin = BlueLED;
    GPIO_Init( BlueLED_Port, &GPIO_InitStructure );
#endif

#ifdef LED1_pin
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );  //   LED1_ClkPort, ENABLE );
    GPIO_InitStructure.GPIO_Pin = LED1_pin;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init( LED1_Port, &GPIO_InitStructure);
#endif

printf("GPIO Init\n");

}

void GPIO_Blink() {

static uint8_t i = 0, k = 1;

	while(1)
	{
		Delay_Ms( 50 );

#ifdef BlueLED
		GPIO_WriteBit( BlueLED_Port, BlueLED, (i == 0) ? (i = Bit_SET) : (i = Bit_RESET));
		GPIO_WriteBit( YelLED_Port, YelLED,   (k == 1) ? (k = Bit_RESET) : (k = Bit_SET));
#endif

#ifdef LED1_pin
		GPIO_WriteBit( LED1_Port , LED1_pin, (i == 0) ? (i = Bit_SET)   : (i = Bit_RESET));
		GPIO_WriteBit( LED2_Port , LED2_pin, (k == 1) ? (k = Bit_RESET) : (k = Bit_SET));
#endif
		}
    }


