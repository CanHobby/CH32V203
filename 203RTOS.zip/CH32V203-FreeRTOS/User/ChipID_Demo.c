/** ChipID_Demo.c
 *  Created on: Jan. 8, 2025
 *      Author: CanHoby.ca
 */

// #include "Periphs.h"

#include "debug.h"
#define  CHIP_MASK 0xF0500

/**      ChipID List
	CH32V203C8U6-0x203005x0
 * 	CH32V203C8T6-0x203105x0
 *  CH32V203K8T6-0x203205x0
 *  CH32V203C6T6-0x203305x0
 *  CH32V203K6T6-0x203505x0
 *  CH32V203G6U6-0x203605x0
 *  CH32V203G8R6-0x203B05x0
 *  CH32V203F8U6-0x203E05x0
 *  CH32V203F6P6-0x203705x0-0x203905x0
 *  CH32V203F8P6-0x203A05x0
 *  CH32V203RBT6-0x203405xC
 *  CH32V208WBU6-0x208005xC
 *  CH32V208RBT6-0x208105xC
 *  CH32V208CBU6-0x208205xC
 *  CH32V208GBU6-0x208305xC
 *
 *  4 = 16 Kbytes of Flash
    6 = 32 Kbytes
    7 = 48 Kbytes
    8 = 64 Kbytes
    B = 128 Kbytes
    C = 256 Kbytes
 */

	uint32_t chip;
	uint8_t  mem;

void ChipID() {


	char     *var;

	chip = DBGMCU_GetCHIPID();
    printf( "Chip = CH32V%03x ", chip >> 20, chip >> 20 );
//    printf( "Chip = CH32V%03x %d ", chip >> 20, chip >> 20 );

    if( (chip & CHIP_MASK) == 0x00500 ) var = "C8U6";
    if( (chip & CHIP_MASK) == 0x10500 ) var = "C8T6";
    if( (chip & CHIP_MASK) == 0x20500 ) var = "K8T6";
    if( (chip & CHIP_MASK) == 0x30500 ) var = "C6T6";

    if( var[1] == '8' )   mem = 64;
    if( var[1] == '6' )   mem = 32;

    printf( "%s (%dK Flash)\n", var, mem );

}


